import { z } from "zod";
import { USER_ACCESSIBILITY } from "../user/user.constant";


const  LoginSchema = z.object({
  body: z.object({
    email:z.string({required_error:"email is optional"}).optional(),
 phoneNumber: z.string({required_error:"Phone Number is required"}).optional(),
    password: z.string({ required_error: "password is required" }),
  }),
  fcm: z.string({ required_error: "fcm is not required" }).optional(),
});

const requestTokenValidationSchema = z.object({
  cookies: z.object({
    refreshToken: z.string({ required_error: "Refresh Token is Required" }),
  }),
});

const forgetPasswordValidation = z.object({
  body: z.object({
    email: z.string({ required_error: "email is required" }).email(),
  }),
});

const resetVerification = z.object({
  body: z.object({
    verificationCode: z
      .number({ required_error: "varification code is required" })
      .min(6, { message: "min 6 character accepted" })
      .optional(),
    newpassword: z
      .string({ required_error: "new password is required" })
      .min(6, { message: "min 6 charcter accepted" })
      .optional(),
  }),
});

const changeMyProfileSchema = z.object({
  body: z.object({
    name: z
      .string({ required_error: "user name is required" })
      .min(3, { message: "min 3 character accepted" })
      .max(50, { message: "max 15 character accepted" })
      .optional(),

    photo: z.string({ required_error: "optional photot" }).url().optional(), 
   language: z.array(z.string({required_error:"language is not required"})).optional(),
   hobbies:z.array(z.string({required_error:"hobbies is not required"})).optional(),
    age: z.string({message:" age is not required"}).optional(),
    nickname: z.string({required_error:" nickname is not Required"}).optional(),
  }),
});

const changeUserAccountStatus = z.object({
  body: z.object({
    status: z.enum([USER_ACCESSIBILITY.isProgress, USER_ACCESSIBILITY.blocked]),
  }),
});


const userVerificationSchema=z.object({
  body: z.object({
    isVerify:z.boolean({required_error:" isVerified  is required"})
  })
})



const LoginValidationSchema = {
  LoginSchema,
  requestTokenValidationSchema,
  forgetPasswordValidation,
  resetVerification,
  changeMyProfileSchema,
  changeUserAccountStatus,
   userVerificationSchema

};
export default LoginValidationSchema;
