// chatbot.controller.ts

import { Request, RequestHandler, Response } from "express";
import httpStatus from "http-status";
import catchAsync from "../../utility/catchAsync";
import sendRespone from "../../utility/sendRespone";
import chatBotServices from "./chatbot.services";

/**
 * Handle text to text chat requests
 * POST /api/v1/chat/text_to_text
 */
const textToTextChat: RequestHandler = catchAsync(
  async (req: Request, res: Response): Promise<void> => {
    const { text, history } = req.body;
    const userId = req.user?.id || "guest";

    // Validate input
    if (!text || typeof text !== "string" || text.trim() === "") {
      sendRespone(res, {
        statusCode: httpStatus.BAD_REQUEST,
        success: false,
        message: "Text is required and must be a non-empty string",
        data: null,
      });
      return;
    }

    try {
      const result = await chatBotServices.textToTextChatIntoDb(userId, text.trim(), history);

      // Directly return the AI JSON output
      sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "Chat response generated successfully",
        data: result, // result already has {message, expression, sessionId, timestamp, historyCount}
      });
    } catch (error) {
      sendRespone(res, {
        statusCode: httpStatus.INTERNAL_SERVER_ERROR,
        success: false,
        message:
          error instanceof Error ? error.message : "Error generating chat response",
        data: null,
      });
    }
  }
);

/**
 * Get chat history for authenticated user
 * GET /api/v1/chat/history
 */
const getChatHistory: RequestHandler = catchAsync(
  async (req: Request, res: Response): Promise<void> => {
    const userId = req.user?.id || "guest";

    if (!userId) {
      sendRespone(res, {
        statusCode: httpStatus.BAD_REQUEST,
        success: false,
        message: "User ID is required",
        data: null,
      });
      return;
    }

    try {
      const result = await chatBotServices.getChatHistory(userId);

      sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "Chat history retrieved successfully",
        data: result,
      });
    } catch (error) {
      sendRespone(res, {
        statusCode: httpStatus.INTERNAL_SERVER_ERROR,
        success: false,
        message:
          error instanceof Error
            ? error.message
            : "Error retrieving chat history",
        data: null,
      });
    }
  }
);


const deleteChatBotInfoInfo:RequestHandler=catchAsync(async(req , res)=>{


     const result=await chatBotServices.deleteChatBotInfoInfoDb(req.user.id, req.params.id);
    sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully delete",
        data: result,
      });

});


const  chatDataStore:RequestHandler=catchAsync(async(req , res)=>{


     const  result=await chatBotServices.chatDataStoreIntoDb(req.body, req.user.id);
      sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully recorded",
        data: result,
      });
});


const  conversationMemoryRecorded:RequestHandler=catchAsync(async(req , res)=>{
  const  result=await chatBotServices.conversationMemoryRecordedIntoDb(req, req.user.id);
      sendRespone(res, {
        statusCode: httpStatus.CREATED,
        success: true,
        message: "successfully recorded",
        data: result,
      });
});


const findMyAllConversation:RequestHandler=catchAsync(async(req, res)=>{
   const result=await chatBotServices.findMyAllConversationIntoDb(req.user.id, req.query);
    sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully Find My Conversation",
        data: result,
      });


});


const findAllConversation:RequestHandler=catchAsync(async(req, res)=>{
   const result=await chatBotServices.findAllConversationIntoDb(req.query, req.params.userId);
    sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully Find All Conversation",
        data: result,
      });
});


const  deleteConversationMemory:RequestHandler=catchAsync(async(req , res)=>{
  const result=await chatBotServices.deleteConversationMemoryFromDb(req.params.id);
    sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully delete",
        data: result,
      });
});


const getConversationGrowth:RequestHandler=catchAsync(async(req , res)=>{
  const result=await chatBotServices.getConversationGrowthIntoDb(req.query);
      sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully get conversation growth",
        data: result,
      });
});

const  findAllConversationZip:RequestHandler=catchAsync(async(req , res)=>{
 const result=await chatBotServices.findAllConversationZipIntoDb(req.query, req.params.userId, res);
      sendRespone(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: "successfully get conversation growth",
        data: result,
      });


});



const chatBotController = {
  textToTextChat,
  getChatHistory,
   deleteChatBotInfoInfo,
   chatDataStore,
   conversationMemoryRecorded,
    findMyAllConversation,
    findAllConversation,
    deleteConversationMemory,
     getConversationGrowth,
     findAllConversationZip
};

export default chatBotController;
